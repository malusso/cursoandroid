package com.example.prueba.ui.Categorias;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.prueba.R;
import com.example.prueba.ui.Calendario.CalendarioViewModel;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Categorias.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Categorias#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Categorias extends Fragment {

    private CategoriasViewModel categoriasViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        categoriasViewModel =
                ViewModelProviders.of(this).get(CategoriasViewModel.class);
        View root = inflater.inflate(R.layout.fragment_categorias, container, false);
        final TextView textView = root.findViewById(R.id.categorias);
        categoriasViewModel.getText().observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        return root;
    }
}